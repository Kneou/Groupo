// copied from EmployeeGetSet class ni Zachh
package loginandregister;

/**
 *
 * @author Kneou
 */
public class EmployeeGetSet {
        private String employeeID;
        private String firstName;
        private String lastName;
        private String birthDay;
        private String address;
        private String phoneNumber;
        private String sssNumber;
        private String tinNumber;
        private String pagIbigNumber;
        private String philHealth;
        private String status;
        private String position;
        private String immediateSupervisor;
        private String basicSalary;
        private String riceSubsidy;
        private String hourlyRate;
        private String phoneAllowance;
        private String grossSemiMonthly;
        

    public EmployeeGetSet() {
    }

    public String getEmployeeID() {
        return employeeID;
    }

    public String getFirstName() {
        return firstName;
    }
    
    public String getLastName(){
        return lastName;
    }
    
 

    public String getBirthDay() {
        return birthDay;
    }


    public String getAddress() {
        return address;
    }

    public String getPhoneNumber() {
        return phoneNumber;
    }

    public String getSssNumber() {
        return sssNumber;
    }

    public String getTinNumber() {
        return tinNumber;
    }

    public String getPagIbigNumber() {
        return pagIbigNumber;
    }

    public String getPhilHealth() {
        return philHealth;
    }

    public String getStatus() {
        return status;
    }

    public String getPosition() {
        return position;
    }

    public String getImmediateSupervisor() {
        return immediateSupervisor;
    }

    public String getBasicSalary() {
        return basicSalary;
    }

    public String getRiceSubsidy() {
        return riceSubsidy;
    }

    public String getHourlyRate() {
        return hourlyRate;
    }

    public String getPhoneAllowance() {
        return phoneAllowance;
    }

     public String getGrossSemiMonthly() {
        return grossSemiMonthly;
    }
     
    public void setEmployeeID(String employeeNumber) {
        this.employeeID = employeeNumber;
    }

    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }
    
    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    public void setBirthDay(String birthDay) {
        this.birthDay = birthDay;
    }

 

    public void setAddress(String address) {
        this.address = address;
    }

    public void setPhoneNumber(String phoneNumber) {
        this.phoneNumber = phoneNumber;
    }

    public void setSssNumber(String sssNumber) {
        this.sssNumber = sssNumber;
    }

    public void setTinNumber(String tinNumber) {
        this.tinNumber = tinNumber;
    }

    public void setPagIbigNumber(String pagIbigNumber) {
        this.pagIbigNumber = pagIbigNumber;
    }

    public void setPhilHealth(String philHealth) {
        this.philHealth = philHealth;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public void setPosition(String position) {
        this.position = position;
    }

    public void setImmediateSupervisor(String immediateSupervisor) {
        this.immediateSupervisor = immediateSupervisor;
    }

    public void setBasicSalary(String basicSalary) {
        this.basicSalary = basicSalary;
    }

    public void setRiceSubsidy(String riceSubsidy) {
        this.riceSubsidy = riceSubsidy;
    }

    public void setHourlyRate(String hourlyRate) {
        this.hourlyRate = hourlyRate;
    }

    public void setPhoneAllowance(String phoneAllowance) {
        this.phoneAllowance = phoneAllowance;
    }
    public void setGrossSemiMonthly( String grossSemiMonthly) {
        this.grossSemiMonthly = grossSemiMonthly;
    }

  
    
}
